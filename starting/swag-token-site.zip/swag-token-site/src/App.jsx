import { useState } from 'react'
import TokenSalePage from './components/ContractRendering/TokenSalePage'

function App() {

  return (
    <div className="App">
      <TokenSalePage/>
    </div>
  )
}

export default App
