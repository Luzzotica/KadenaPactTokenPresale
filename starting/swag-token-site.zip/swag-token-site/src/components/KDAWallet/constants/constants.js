export const X_WALLET = 'X_WALLET';
export const ZELCORE = 'ZELCORE';

export const EVENT_NEW_TX = 'new_transaction';
export const EVENT_NEW_MSG = 'new_message';
export const EVENT_WALLET_CONNECT = 'wallet_connected';