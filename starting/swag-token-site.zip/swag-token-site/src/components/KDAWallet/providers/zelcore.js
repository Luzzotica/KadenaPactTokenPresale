

export const ZELCORE = 'ZELCORE';
const zelcore = {
  name: 'Zelcore',
  connect: async function(state) {
    // Wallet Integration and Signing: Wallet Connection and Disconnection
  },
  disconnect: async function(state) {
    // Wallet Integration and Signing: Wallet Connection and Disconnection
  },
  sign: async function(state, signingCommand) {
    // Wallet Integration and Signing: Supporting Functions
  }
}
export default zelcore;